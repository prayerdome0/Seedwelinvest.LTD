AI CERTIFICATE SAMPLE COLLECTION

Total providers: 167
Verified actual certificate pictures: 104
Pending public certificate samples: 63

Open index.html to browse the complete gallery.
01-verified-actual-certificates contains verified full certificate documents.
02-pending-public-certificate-samples contains retained badge or credential images that must not be represented as full certificate documents.
MANIFEST.csv identifies every provider, status, image filename, and source URL.
